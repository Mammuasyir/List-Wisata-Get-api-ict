package com.example.listwisata.presenter

interface MainConstruct {

    interface view{

    }

    interface Presenter{
        fun getAllWisata()
        fun addWisata(katWisata: Int, nameWisata: String, priceWisata: String, descWisata: String, cityWisata: String, provinceWisata: String, addressWisata: String, openWisata: String, latWisata: String, longWisata: String, imgWisata: String)
    }
}