package com.example.listwisata.api

import com.example.listwisata.model.ResponseListWisata
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST


interface ApiService {
    @GET("wisata")
    fun getWisata() : Call<ResponseListWisata>

    @FormUrlEncoded
    @POST("add-wisata")
    fun addWisata(
        @Field("kategori_id") katWisata: Int,
        @Field("nama_wisata") nameWisata: String,
        @Field("harga") priceWisata: String,
        @Field("deskripsi") descWisata: String,
        @Field("kota") cityWisata: String,
        @Field("provinsi") provinceWisata: String,
        @Field("alamat") addressWisata: String,
        @Field("waktu_buka") openWisata: String,
        @Field("latitude") latWisata: String,
        @Field("longitude") longWisata: String,
        @Field("image") imgWisata: String,
    ): Call<ResponseListWisata>
}